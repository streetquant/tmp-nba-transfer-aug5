#!/usr/bin/env python3
from __future__ import annotations
import csv, io, json, math, hashlib, zipfile
from pathlib import Path
from datetime import datetime, timezone
import pandas as pd, requests

ROOT=Path(__file__).resolve().parents[1]
CAN=ROOT/'processed/nifty_futidx_individual_contracts_official_through_2018.csv'
RAW=ROOT/'raw/bhavcopy_validation_samples'; RAW.mkdir(parents=True,exist_ok=True)
OUT=ROOT/'reports'; OUT.mkdir(parents=True,exist_ok=True)
UA='Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36'

def sha(p):
 h=hashlib.sha256(); h.update(p.read_bytes()); return h.hexdigest()

def f(x):
 try:return float(x)
 except:return float('nan')

df=pd.read_csv(CAN,parse_dates=['trade_date','expiry_date'])
dates=pd.DatetimeIndex(sorted(df.trade_date.unique()))
# Deterministic quantile sample plus the known anomaly date and final date.
indices=sorted(set(int(round(q*(len(dates)-1))) for q in [0,.05,.1,.2,.3,.4,.5,.6,.7,.8,.9,.95,1]))
sample=list(dates[indices])
for special in [pd.Timestamp('2002-09-27'),pd.Timestamp('2018-01-05')]:
 if special in dates and special not in sample: sample.append(special)
sample=sorted(sample)
results=[]; differences=[]; session=requests.Session(); session.headers.update({'User-Agent':UA,'Referer':'https://www.nseindia.com/'})
for d in sample:
 mon=d.strftime('%b').upper(); name=f"fo{d.strftime('%d%b%Y').upper()}bhav.csv.zip"
 url=f"https://nsearchives.nseindia.com/content/historical/DERIVATIVES/{d.year}/{mon}/{name}"
 p=RAW/name
 if not p.exists():
  r=session.get(url,timeout=90); r.raise_for_status(); p.write_bytes(r.content)
 with zipfile.ZipFile(p) as z:
  member=z.namelist()[0]
  br=list(csv.DictReader(io.TextIOWrapper(z.open(member),encoding='utf-8-sig')))
 b=[r for r in br if r.get('INSTRUMENT')=='FUTIDX' and r.get('SYMBOL')=='NIFTY']
 a=df[df.trade_date==d]
 bmap={pd.to_datetime(r['EXPIRY_DT'],format='%d-%b-%Y'):r for r in b}
 amap={r.expiry_date:r for r in a.itertuples()}
 keys=sorted(set(amap)|set(bmap))
 daydiff=[]
 for e in keys:
  ar=amap.get(e); br=bmap.get(e)
  if ar is None or br is None:
   daydiff.append({'expiry':e.date().isoformat(),'field':'row_presence','api':ar is not None,'bhavcopy':br is not None}); continue
  checks={
   'open':(float(ar.open),f(br['OPEN']),1e-9), 'high':(float(ar.high),f(br['HIGH']),1e-9),
   'low':(float(ar.low),f(br['LOW']),1e-9), 'close':(float(ar.close),f(br['CLOSE']),1e-9),
   'settle':(float(ar.settle),f(br['SETTLE_PR']),1e-9),
   'traded_quantity_units':(float(ar.contracts),f(br['CONTRACTS'])*float(ar.market_lot),1e-6),
   'open_interest_units':(float(ar.open_interest),f(br['OPEN_INT']),1e-6),
   'change_in_oi_units':(float(ar.change_in_oi),f(br['CHG_IN_OI']),1e-6),
   'turnover_lakh':(float(ar.turnover_lakh),f(br['VAL_INLAKH']),0.02),
  }
  # The API encodes completely inactive far contracts as null while the daily
  # bhavcopy encodes the same absence of activity as zero. Treat this purely
  # representational null-vs-zero case as equivalent; never normalize an active
  # contract or a nonzero field.
  inactive_bhavcopy = all(abs(f(br[k])) == 0.0 for k in ['OPEN','HIGH','LOW','CLOSE','SETTLE_PR','CONTRACTS','VAL_INLAKH','OPEN_INT','CHG_IN_OI'])
  for field,(x,y,tol) in checks.items():
   null_zero_equivalent = inactive_bhavcopy and math.isnan(x) and y == 0.0
   if not (null_zero_equivalent or math.isclose(x,y,rel_tol=0,abs_tol=tol) or (math.isnan(x) and math.isnan(y))):
    daydiff.append({'expiry':e.date().isoformat(),'field':field,'api':x,'bhavcopy':y,'abs_diff':abs(x-y)})
 differences.extend([{'trade_date':d.date().isoformat(),**x} for x in daydiff])
 results.append({'trade_date':d.date().isoformat(),'url':url,'file':str(p.relative_to(ROOT)),'sha256':sha(p),'api_rows':len(a),'bhavcopy_rows':len(b),'difference_count':len(daydiff)})
report={'retrieved_at_utc':datetime.now(timezone.utc).isoformat(),'canonical_sha256':sha(CAN),'sample_count':len(sample),'sample_results':results,'difference_count':len(differences),'differences':differences,'normalization_rule':'Completely inactive bhavcopy zero rows are equivalent to API null fields; active/nonzero rows are never normalized.'}
(OUT/'bhavcopy_reconciliation.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
pd.DataFrame(differences).to_csv(OUT/'bhavcopy_reconciliation_differences.csv',index=False)
print(json.dumps({'sample_count':len(sample),'difference_count':len(differences),'dates':[x['trade_date'] for x in results],'canonical_sha256':report['canonical_sha256']},indent=2))
