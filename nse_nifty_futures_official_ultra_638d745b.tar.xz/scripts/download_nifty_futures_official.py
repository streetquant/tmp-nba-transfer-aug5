#!/usr/bin/env python3
"""Download official NSE NIFTY FUTIDX contract history, development period only.

Hard safety invariant: no request or accepted row may exceed 2018-12-31.
Raw JSON responses are immutable and resumable. Windows are at most 14 calendar days
because the NSE endpoint returns at most about 70 rows and silently truncates broad queries.
"""
from __future__ import annotations

import csv
import hashlib
import json
import os
import random
import sys
import time
from dataclasses import dataclass, asdict
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Any
from urllib.parse import urlencode

import requests

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "raw" / "nse_fo_api_windows_14d"
LOG = ROOT / "logs" / "nse_fo_api_download.jsonl"
PROCESSED = ROOT / "processed"
START = date(2000, 1, 1)
END = date(2018, 12, 31)
WINDOW_DAYS = 14
BASE = "https://www.nseindia.com/api/historicalOR/foCPV"
LANDING = "https://www.nseindia.com/report-detail/fo_eq_security"

HEADERS = {
    "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
                  "(KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36",
    "Accept": "application/json,text/plain,*/*",
    "Accept-Language": "en-US,en;q=0.9",
    "Referer": LANDING,
}

@dataclass(frozen=True)
class Window:
    start: date
    end: date

    @property
    def key(self) -> str:
        return f"{self.start.isoformat()}_{self.end.isoformat()}"

    @property
    def path(self) -> Path:
        return RAW / f"nifty_futidx_{self.key}.json"

    @property
    def url(self) -> str:
        params = {
            "from": self.start.strftime("%d-%m-%Y"),
            "to": self.end.strftime("%d-%m-%Y"),
            "instrumentType": "FUTIDX",
            "symbol": "NIFTY",
            "year": str(self.start.year),
        }
        return f"{BASE}?{urlencode(params)}"


def sha256_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def sha256_file(p: Path) -> str:
    h = hashlib.sha256()
    with p.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def parse_date(s: str) -> date:
    return datetime.strptime(s, "%d-%b-%Y").date()


def windows() -> list[Window]:
    out: list[Window] = []
    cur = START
    while cur <= END:
        end = min(cur + timedelta(days=WINDOW_DAYS - 1), END)
        out.append(Window(cur, end))
        cur = end + timedelta(days=1)
    return out


def validate_payload(payload: Any, w: Window) -> list[dict[str, Any]]:
    if not isinstance(payload, dict) or not isinstance(payload.get("data"), list):
        raise ValueError("payload must be object with list field 'data'")
    rows = payload["data"]
    for i, r in enumerate(rows):
        if not isinstance(r, dict):
            raise ValueError(f"row {i} is not object")
        if r.get("FH_INSTRUMENT") != "FUTIDX" or r.get("FH_SYMBOL") != "NIFTY":
            raise ValueError(f"foreign instrument at row {i}: {r.get('FH_INSTRUMENT')}/{r.get('FH_SYMBOL')}")
        d = parse_date(str(r["FH_TIMESTAMP"]))
        if not (w.start <= d <= w.end):
            raise ValueError(f"row date {d} outside requested window {w.start}..{w.end}")
        if d > END:
            raise ValueError(f"post-development row rejected: {d}")
        # Some official bhavcopies contain traded rows one session after the nominal
        # expiry label (confirmed for 27-Sep-2002). Preserve such rows and record
        # them as anomalies; observed official trading is stronger evidence of
        # existence than the nominal label alone.
        parse_date(str(r["FH_EXPIRY_DT"]))
    if len(rows) >= 70:
        raise ValueError(f"possible NSE response-cap truncation: {len(rows)} rows")
    return rows


def append_log(record: dict[str, Any]) -> None:
    LOG.parent.mkdir(parents=True, exist_ok=True)
    with LOG.open("a", encoding="utf-8") as f:
        f.write(json.dumps(record, sort_keys=True, separators=(",", ":")) + "\n")
        f.flush()
        os.fsync(f.fileno())


def download_window(session: requests.Session, w: Window, max_attempts: int = 8) -> tuple[list[dict[str, Any]], str, bool]:
    if w.path.exists():
        raw = w.path.read_bytes()
        payload = json.loads(raw)
        rows = validate_payload(payload, w)
        return rows, sha256_bytes(raw), True

    for attempt in range(1, max_attempts + 1):
        try:
            r = session.get(w.url, timeout=90)
            if r.status_code in {401, 403, 429, 503}:
                session.get(LANDING, timeout=45)
                delay = min(30.0, (1.7 ** attempt) + random.random())
                append_log({"window": w.key, "attempt": attempt, "status": r.status_code, "retry_seconds": delay})
                time.sleep(delay)
                continue
            r.raise_for_status()
            raw = r.content
            payload = r.json()
            rows = validate_payload(payload, w)
            w.path.parent.mkdir(parents=True, exist_ok=True)
            tmp = w.path.with_suffix(".tmp")
            tmp.write_bytes(raw)
            os.replace(tmp, w.path)
            digest = sha256_bytes(raw)
            append_log({"window": w.key, "attempt": attempt, "status": r.status_code,
                        "rows": len(rows), "sha256": digest, "url": w.url})
            return rows, digest, False
        except Exception as exc:
            delay = min(30.0, (1.7 ** attempt) + random.random())
            append_log({"window": w.key, "attempt": attempt, "error": repr(exc), "retry_seconds": delay})
            if attempt == max_attempts:
                raise
            time.sleep(delay)
    raise AssertionError("unreachable")


def canonical_row(r: dict[str, Any]) -> dict[str, Any]:
    date_fields = {
        "trade_date": parse_date(str(r["FH_TIMESTAMP"])).isoformat(),
        "expiry_date": parse_date(str(r["FH_EXPIRY_DT"])).isoformat(),
    }
    mapping = {
        "instrument": r.get("FH_INSTRUMENT"),
        "symbol": r.get("FH_SYMBOL"),
        "market_type": r.get("FH_MARKET_TYPE"),
        "option_type": r.get("FH_OPTION_TYPE"),
        "strike_price": r.get("FH_STRIKE_PRICE"),
        "open": r.get("FH_OPENING_PRICE"),
        "high": r.get("FH_TRADE_HIGH_PRICE"),
        "low": r.get("FH_TRADE_LOW_PRICE"),
        "close": r.get("FH_CLOSING_PRICE"),
        "last": r.get("FH_LAST_TRADED_PRICE"),
        "previous_close": r.get("FH_PREV_CLS"),
        "settle": r.get("FH_SETTLE_PRICE"),
        "contracts": r.get("FH_TOT_TRADED_QTY"),
        "turnover_lakh": r.get("FH_TOT_TRADED_VAL"),
        "open_interest": r.get("FH_OPEN_INT"),
        "change_in_oi": r.get("FH_CHANGE_IN_OI"),
        "underlying_value": r.get("FH_UNDERLYING_VALUE"),
        "market_lot": r.get("FH_MARKET_LOT"),
    }
    return {**date_fields, **mapping}


def main() -> int:
    RAW.mkdir(parents=True, exist_ok=True)
    PROCESSED.mkdir(parents=True, exist_ok=True)
    session = requests.Session()
    session.headers.update(HEADERS)
    session.get(LANDING, timeout=45)

    all_rows: list[dict[str, Any]] = []
    raw_manifest: list[dict[str, Any]] = []
    reused = 0
    for idx, w in enumerate(windows(), 1):
        rows, digest, was_reused = download_window(session, w)
        reused += int(was_reused)
        all_rows.extend(canonical_row(r) for r in rows)
        raw_manifest.append({"start": w.start.isoformat(), "end": w.end.isoformat(),
                             "file": str(w.path.relative_to(ROOT)), "sha256": digest,
                             "rows": len(rows), "reused": was_reused, "url": w.url})
        if idx % 20 == 0 or idx == len(windows()):
            print(f"windows={idx}/{len(windows())} rows_accumulated={len(all_rows)} reused={reused}", flush=True)
        time.sleep(0.12 + random.random() * 0.08)

    key_fields = ("trade_date", "expiry_date", "instrument", "symbol", "strike_price", "option_type")
    seen: dict[tuple[Any, ...], dict[str, Any]] = {}
    exact_duplicate_count = 0
    conflicting_duplicates: list[dict[str, Any]] = []
    for row in all_rows:
        key = tuple(row[k] for k in key_fields)
        if key in seen:
            if row == seen[key]:
                exact_duplicate_count += 1
            else:
                conflicting_duplicates.append({"key": key, "first": seen[key], "second": row})
        else:
            seen[key] = row
    if conflicting_duplicates:
        raise ValueError(f"conflicting duplicate contract rows: {len(conflicting_duplicates)}")

    rows = sorted(seen.values(), key=lambda x: (x["trade_date"], x["expiry_date"]))
    anomalies = [r for r in rows if r["trade_date"] > r["expiry_date"]]
    anomaly_path = PROCESSED / "official_data_anomalies.csv"
    if anomalies:
        with anomaly_path.open("w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=list(anomalies[0]))
            w.writeheader(); w.writerows(anomalies)
    else:
        anomaly_path.write_text("trade_date,expiry_date\n", encoding="utf-8")
    if not rows:
        raise ValueError("no rows downloaded")
    if max(r["trade_date"] for r in rows) > END.isoformat():
        raise ValueError("post-development row detected after merge")

    out_csv = PROCESSED / "nifty_futidx_individual_contracts_official_through_2018.csv"
    fields = list(rows[0])
    tmp_csv = out_csv.with_suffix(".tmp")
    with tmp_csv.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader(); w.writerows(rows)
    os.replace(tmp_csv, out_csv)

    trade_dates = sorted({r["trade_date"] for r in rows})
    expiries = sorted({r["expiry_date"] for r in rows})
    lots_by_date: dict[str, list[int]] = {}
    for r in rows:
        lot = r.get("market_lot")
        if lot is not None:
            lots_by_date.setdefault(r["trade_date"], []).append(int(lot))
    lot_values = sorted({lot for v in lots_by_date.values() for lot in v})

    manifest = {
        "schema_version": 1,
        "source": "National Stock Exchange of India historicalOR/foCPV API",
        "endpoint": BASE,
        "retrieved_at_utc": datetime.utcnow().replace(microsecond=0).isoformat() + "Z",
        "hard_query_end": END.isoformat(),
        "window_days": WINDOW_DAYS,
        "windows": len(raw_manifest),
        "raw_window_manifest": raw_manifest,
        "raw_rows_before_dedup": len(all_rows),
        "exact_duplicate_count": exact_duplicate_count,
        "conflicting_duplicate_count": len(conflicting_duplicates),
        "canonical_rows": len(rows),
        "trade_date_min": trade_dates[0],
        "trade_date_max": trade_dates[-1],
        "trade_dates": len(trade_dates),
        "expiry_count": len(expiries),
        "market_lot_values": lot_values,
        "nominal_post_expiry_observed_rows": len(anomalies),
        "anomaly_csv": str(anomaly_path.relative_to(ROOT)),
        "anomaly_csv_sha256": sha256_file(anomaly_path),
        "canonical_csv": str(out_csv.relative_to(ROOT)),
        "canonical_csv_sha256": sha256_file(out_csv),
        "raw_manifest_sha256": hashlib.sha256(json.dumps(raw_manifest, sort_keys=True, separators=(",", ":")).encode()).hexdigest(),
    }
    manifest_path = PROCESSED / "nifty_futidx_official_manifest.json"
    manifest_path.write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({k: manifest[k] for k in ["canonical_rows", "trade_date_min", "trade_date_max", "trade_dates", "expiry_count", "market_lot_values", "canonical_csv_sha256"]}, indent=2))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
